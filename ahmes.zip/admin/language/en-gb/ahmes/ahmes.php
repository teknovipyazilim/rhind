<?php
// Locale
$_['ahmes']				= 'Ahmes\'s Formules';
$_['ahmes_formulas']		= 'Formulas for Price';
$_['ahmes_setup']		= 'Setup Ahmes';
$_['txt_setup_table_formula']= 'Setup Formulas Table';
$_['txt_create']			= 'Create Table';
$_['txt_delete']			= 'Delete Table';
$_['txt_id']				= 'Formula Id';
$_['txt_name']				= 'Formula Name';
$_['txt_formula']			= 'Formula';
$_['txt_date_added']		= 'Date Added';
$_['txt_date_modified']		= 'Date Modified';
$_['txt_status']			= 'Status';
$_['txt_actions']			= 'Actions';
$_['button_add ']			= 'Add Formule';
