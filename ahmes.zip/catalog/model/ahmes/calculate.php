<?php
class ModelAhmesCalculate extends Model {
	
}